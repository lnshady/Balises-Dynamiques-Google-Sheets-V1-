# Balises Dynamiques Google Sheets (V3.1)

Plugin WordPress ultra-léger pour synchroniser et afficher des données dynamiques (textes, prix, images) depuis un fichier Google Sheets (CSV) via un shortcode optimisé.

## Fonctionnalités
- Cache global adaptatif : Utilisation des transients natifs de WordPress pour éviter le Cache Stampede.
- Parsing CSV robuste : Support complet de str_getcsv gérant les sauts de ligne encapsulés dans les cellules.
- Sécurité & Performance : Requêtes HTTP bridées à un timeout de 3s avec bypass de proxy (cache buster).

## Démonstration

1. Source Google Sheets : Organisez vos données (ex: Menus, Plats, Prix).
   ![Google Sheets Source](assets/Google%20sheets.png)

2. Intégration Elementor / WordPress : Utilisez le shortcode directement dans vos widgets (ex: [menu row="2" col="1"]).
   ![Shortcode Integration](assets/plug%20in%20short%20code.png)

3. Gestion des pages : Idéal pour l'organisation de menus multilingues ou d'onglets spécifiques (Menus, Allergènes, Vins).
   ![WordPress Pages Overview](assets/trad%20menu%20allerg.png)

## Utilisation

[menu row="2" col="3" type="text" default="En cours..." cache="60"]

### Attributs disponibles :
- row : Index de la ligne (commence à 1).
- col : Index de la colonne (commence à 1).
- type : text (par défaut) ou image/img (génère une balise <img>).
- default : Valeur de secours.
- cache : Durée du transient en secondes (par défaut : 60).

## Configuration

Pour modifier l'URL source du Google Sheet, éditez la constante au début du script principal :
define('RDL_SHEET_URL', 'https://docs.google.com/spreadsheets/d/.../pub?output=csv');

## Licence
Ce projet est sous licence MIT. Voir le fichier LICENSE pour plus de détails.